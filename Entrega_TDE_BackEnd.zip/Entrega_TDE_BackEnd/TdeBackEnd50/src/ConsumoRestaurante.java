public class ConsumoRestaurante implements Cobravel {
    private String prato;
    private double valorPrato;
    private int quantidade;

    public ConsumoRestaurante(String prato, double valorPrato, int quantidade) {
        this.prato = prato;
        this.valorPrato = valorPrato;
        this.quantidade = quantidade;
    }

    @Override
    public String descricao() {
        return "Restaurante: " + prato + " (qtd: " + quantidade + ")";
    }

    @Override
    public double calcularValor() {
        return valorPrato * quantidade;
    }
}
