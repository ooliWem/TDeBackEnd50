public class Main {
    public static void main(String[] args) {

        Quarto[] quartos = {
                new Quarto(101, 180),
                new QuartoLuxo(201, 300, 60),
                new Chale(301, 250, 2)
        };

        for (Quarto q : quartos) {
            q.exibir();
        }

        Cobravel[] itens = {
                new Reserva(quartos[1], 3),
                new Passeio("Lencois Maranhenses", 150, 2),
                new Passeio("Rio Preguicas", 90),
                new ConsumoRestaurante("Frutos do Mar", 85.50, 2)
        };

        Conta conta = new Conta("Bruno Costa", itens);
        conta.imprimirExtrato();
        System.out.println("Com cupom de 10%: R$ " + conta.calcularTotal(10));
    }
}
