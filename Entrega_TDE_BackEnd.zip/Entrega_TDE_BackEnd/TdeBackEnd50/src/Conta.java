public class Conta {
    private String hospede;
    private Cobravel[] itens;

    public Conta(String hospede, Cobravel[] itens) {
        this.hospede = hospede;
        this.itens = itens;
    }

    public double calcularTotal() {
        double total = 0.0;
        for (int i = 0; i < itens.length; i++) {
            total += itens[i].calcularValor();
        }
        return total;
    }

    public double calcularTotal(double descontoPercentual) {
        double total = calcularTotal();
        double desconto = total * descontoPercentual / 100;
        return total - desconto;
    }

    public void imprimirExtrato() {
        System.out.println("Extrato do hospede: " + hospede);
        for (int i = 0; i < itens.length; i++) {
            System.out.println(itens[i].descricao() + " - R$ " + itens[i].calcularValor());
        }
        System.out.println("Total: R$ " + calcularTotal());
    }
}
